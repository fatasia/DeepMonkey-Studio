mergeInto(LibraryManager.library, {
  BimStudioEmit: function (eventNamePtr, payloadJsonPtr) {
    var eventName = UTF8ToString(eventNamePtr);
    var payloadJson = UTF8ToString(payloadJsonPtr);
    var payload = null;
    try { payload = payloadJson ? JSON.parse(payloadJson) : null; } catch (error) { payload = payloadJson; }
    if (window.BimStudioUnityBridge) window.BimStudioUnityBridge.emit(eventName, payload);
  },
  BimStudioError: function (messagePtr) {
    if (window.BimStudioUnityBridge) window.BimStudioUnityBridge.error(UTF8ToString(messagePtr));
  }
});
