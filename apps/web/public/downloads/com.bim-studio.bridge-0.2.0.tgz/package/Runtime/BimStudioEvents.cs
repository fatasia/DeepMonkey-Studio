using System.Runtime.InteropServices;
using UnityEngine;

namespace BimStudio.Bridge
{
    public static class BimStudioEvents
    {
#if UNITY_WEBGL && !UNITY_EDITOR
        [DllImport("__Internal")] private static extern void BimStudioEmit(string eventName, string payloadJson);
        [DllImport("__Internal")] private static extern void BimStudioError(string message);
#endif

        public static void Emit(string eventName, string payloadJson = "null")
        {
#if UNITY_WEBGL && !UNITY_EDITOR
            BimStudioEmit(eventName, payloadJson ?? "null");
#else
            Debug.Log($"[BIM Studio event] {eventName}: {payloadJson}");
#endif
        }

        public static void Error(string message)
        {
#if UNITY_WEBGL && !UNITY_EDITOR
            BimStudioError(message ?? "Unity error");
#else
            Debug.LogError(message);
#endif
        }
    }
}
