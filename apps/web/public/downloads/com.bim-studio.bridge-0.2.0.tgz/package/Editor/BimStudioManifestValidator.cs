using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace BimStudio.Bridge.Editor
{
    public sealed class BimStudioManifestValidation
    {
        public readonly List<string> errors = new List<string>();
        public readonly List<string> warnings = new List<string>();
        public bool IsValid => errors.Count == 0;
    }

    public static class BimStudioManifestValidator
    {
        private static readonly HashSet<string> PropertyTypes = new HashSet<string>(StringComparer.Ordinal)
        {
            "string", "number", "boolean", "color", "select"
        };

        public static BimStudioManifestValidation Validate(BimStudioManifestAsset manifest)
        {
            var result = new BimStudioManifestValidation();
            if (manifest == null)
            {
                result.errors.Add("缺少 BimStudioManifest 集成清单资源。");
                return result;
            }

            ValidateNames("事件", manifest.events, result);
            ValidateNames("动作", manifest.actions, result);
            ValidateDataLayers(manifest.dataLayers ?? Array.Empty<BimStudioDataLayer>(), result);
            ValidateObjects(manifest.objects ?? Array.Empty<BimStudioObject>(), result);
            ValidateProperties(manifest.properties ?? Array.Empty<BimStudioProperty>(), manifest.objects ?? Array.Empty<BimStudioObject>(), result);

            var version = Application.unityVersion ?? string.Empty;
            if (!version.StartsWith("2022.3", StringComparison.Ordinal) && !version.StartsWith("6000.0", StringComparison.Ordinal))
                result.warnings.Add($"Unity {version} 不在已验证版本范围内（2022.3 LTS / 6000.0），请先对当前补丁版本进行构建验证。");
            if (manifest.events == null || manifest.events.Length == 0)
                result.warnings.Add("尚未声明 Unity 发出的事件；场景可以渲染，但平台无法生成类型化的交互选项。");
            return result;
        }

        private static void ValidateNames(string label, IEnumerable<string> values, BimStudioManifestValidation result)
        {
            var seen = new HashSet<string>(StringComparer.Ordinal);
            var index = 0;
            foreach (var raw in values ?? Array.Empty<string>())
            {
                var value = (raw ?? string.Empty).Trim();
                if (value.Length == 0) result.errors.Add($"{label} #{index + 1} 的名称为空。");
                else if (!seen.Add(value)) result.errors.Add($"{label}名称重复：{value}。");
                index++;
            }
        }

        private static void ValidateDataLayers(IEnumerable<BimStudioDataLayer> layers, BimStudioManifestValidation result)
        {
            var seen = new HashSet<string>(StringComparer.Ordinal);
            var index = 0;
            foreach (var layer in layers)
            {
                var key = (layer?.key ?? string.Empty).Trim();
                if (key.Length == 0) result.errors.Add($"数据层 #{index + 1} 的标识为空。");
                else if (!seen.Add(key)) result.errors.Add($"数据层标识重复：{key}。");
                if (layer != null && string.IsNullOrWhiteSpace(layer.target)) result.warnings.Add($"数据层 {key} 没有目标适配器，Unity 项目需要自行路由。");
                index++;
            }
        }

        private static void ValidateObjects(IEnumerable<BimStudioObject> objects, BimStudioManifestValidation result)
        {
            var seen = new HashSet<string>(StringComparer.Ordinal);
            var index = 0;
            foreach (var item in objects)
            {
                var id = (item?.id ?? string.Empty).Trim();
                if (id.Length == 0) result.errors.Add($"业务对象 #{index + 1} 的稳定 ID 为空。");
                else if (!seen.Add(id)) result.errors.Add($"业务对象 ID 重复：{id}。");
                if (item != null && string.IsNullOrWhiteSpace(item.path)) result.warnings.Add($"业务对象 {id} 没有场景路径，运行时需要使用自定义注册表查找。");
                index++;
            }
        }

        private static void ValidateProperties(IEnumerable<BimStudioProperty> properties, IEnumerable<BimStudioObject> objects, BimStudioManifestValidation result)
        {
            var objectIds = new HashSet<string>(objects.Select(item => item?.id).Where(id => !string.IsNullOrWhiteSpace(id)), StringComparer.Ordinal);
            var seen = new HashSet<string>(StringComparer.Ordinal);
            var index = 0;
            foreach (var property in properties)
            {
                var key = (property?.key ?? string.Empty).Trim();
                if (key.Length == 0) result.errors.Add($"可配置属性 #{index + 1} 的标识为空。");
                else if (!seen.Add(key)) result.errors.Add($"可配置属性标识重复：{key}。");
                if (property != null && !PropertyTypes.Contains(property.type ?? string.Empty)) result.errors.Add($"属性 {key} 使用了不支持的类型：{property.type}。");
                if (property != null && !string.IsNullOrWhiteSpace(property.target) && !objectIds.Contains(property.target)) result.errors.Add($"属性 {key} 指向未声明的业务对象：{property.target}。");
                if (property != null && property.type == "select" && (property.options == null || property.options.Length == 0)) result.errors.Add($"选择型属性 {key} 没有可选项。");
                index++;
            }
        }
    }
}
