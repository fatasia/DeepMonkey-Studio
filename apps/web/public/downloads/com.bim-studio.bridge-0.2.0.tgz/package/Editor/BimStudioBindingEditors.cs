using System;
using System.Linq;
using BimStudio.Bridge;
using UnityEditor;
using UnityEngine;

namespace BimStudio.Bridge.Editor
{
    internal static class BimStudioBindingEditorUtility
    {
        internal const string ManifestPath = "Assets/Resources/BimStudioManifest.asset";

        internal static BimStudioManifestAsset LoadManifest()
        {
            return AssetDatabase.LoadAssetAtPath<BimStudioManifestAsset>(ManifestPath);
        }

        internal static void DrawManifestLink(BimStudioManifestAsset manifest)
        {
            if (manifest == null)
            {
                EditorGUILayout.HelpBox("未找到 BIM Studio 集成清单，请先准备项目。", MessageType.Warning);
                if (GUILayout.Button("准备通信桥与集成清单")) BimStudioProjectSetup.Setup();
                return;
            }

            using (new EditorGUILayout.HorizontalScope())
            {
                EditorGUILayout.PrefixLabel("集成清单");
                if (GUILayout.Button(manifest.name, EditorStyles.objectField))
                {
                    Selection.activeObject = manifest;
                    EditorGUIUtility.PingObject(manifest);
                }
            }
        }

        internal static void DrawChoice(SerializedProperty property, string label, string[] values, string emptyMessage, bool includeEmpty = false)
        {
            var choices = includeEmpty ? new[] { "（任意对象）" }.Concat(values).ToArray() : values;
            if (choices.Length == 0)
            {
                EditorGUILayout.HelpBox(emptyMessage, MessageType.Warning);
                EditorGUILayout.PropertyField(property, new GUIContent(label));
                return;
            }

            var offset = includeEmpty ? 1 : 0;
            var currentIndex = Array.IndexOf(values, property.stringValue);
            var current = currentIndex < 0 ? 0 : currentIndex + offset;
            var selected = EditorGUILayout.Popup(label, current, choices);
            property.stringValue = includeEmpty && selected == 0 ? string.Empty : values[Math.Max(0, selected - offset)];
        }
    }

    [CustomEditor(typeof(BimStudioValueBinding))]
    public sealed class BimStudioValueBindingEditor : UnityEditor.Editor
    {
        public override void OnInspectorGUI()
        {
            serializedObject.Update();
            var manifest = BimStudioBindingEditorUtility.LoadManifest();
            BimStudioBindingEditorUtility.DrawManifestLink(manifest);

            var source = serializedObject.FindProperty("source");
            var key = serializedObject.FindProperty("key");
            var target = serializedObject.FindProperty("target");
            source.enumValueIndex = EditorGUILayout.Popup("监听来源", source.enumValueIndex, new[] { "数据层", "可配置属性" });

            var sourceValue = (BimStudioValueSource)source.enumValueIndex;
            var keys = sourceValue == BimStudioValueSource.DataLayer
                ? manifest?.dataLayers?.Select(item => item.key).Where(value => !string.IsNullOrWhiteSpace(value)).ToArray() ?? Array.Empty<string>()
                : manifest?.properties?.Select(item => item.key).Where(value => !string.IsNullOrWhiteSpace(value)).ToArray() ?? Array.Empty<string>();
            BimStudioBindingEditorUtility.DrawChoice(key, sourceValue == BimStudioValueSource.DataLayer ? "数据层" : "可配置属性", keys, "请先在集成清单中声明标识，再在这里选择。");

            EditorGUILayout.Space(4);
            target.enumValueIndex = EditorGUILayout.Popup("更新目标", target.enumValueIndex, new[]
            {
                "对象显示 / 隐藏", "Animator 浮点参数", "Animator 布尔参数", "Animator 触发器",
                "材质浮点属性", "材质颜色", "位置 X", "位置 Y", "位置 Z", "旋转 X", "旋转 Y", "旋转 Z",
                "缩放 X", "缩放 Y", "缩放 Z", "触发 UnityEvent"
            });
            var targetValue = (BimStudioValueTarget)target.enumValueIndex;
            if (targetValue != BimStudioValueTarget.InvokeEvent)
                EditorGUILayout.PropertyField(serializedObject.FindProperty("targetObject"), new GUIContent("目标对象"));
            if (targetValue == BimStudioValueTarget.AnimatorFloat || targetValue == BimStudioValueTarget.AnimatorBool || targetValue == BimStudioValueTarget.AnimatorTrigger)
            {
                EditorGUILayout.PropertyField(serializedObject.FindProperty("animator"), new GUIContent("Animator 组件"));
                EditorGUILayout.PropertyField(serializedObject.FindProperty("parameter"), new GUIContent("Animator 参数"));
            }
            if (targetValue == BimStudioValueTarget.MaterialFloat || targetValue == BimStudioValueTarget.MaterialColor)
            {
                EditorGUILayout.PropertyField(serializedObject.FindProperty("targetRenderer"), new GUIContent("渲染器"));
                EditorGUILayout.PropertyField(serializedObject.FindProperty("parameter"), new GUIContent("Shader 属性"));
            }
            if (targetValue == BimStudioValueTarget.InvokeEvent)
                EditorGUILayout.PropertyField(serializedObject.FindProperty("onValue"), new GUIContent("收到数据时"));

            if (string.IsNullOrWhiteSpace(key.stringValue))
                EditorGUILayout.HelpBox("构建 WebGL 前请选择集成清单中的标识。", MessageType.Error);
            serializedObject.ApplyModifiedProperties();
        }
    }

    [CustomEditor(typeof(BimStudioActionBinding))]
    public sealed class BimStudioActionBindingEditor : UnityEditor.Editor
    {
        public override void OnInspectorGUI()
        {
            serializedObject.Update();
            var manifest = BimStudioBindingEditorUtility.LoadManifest();
            BimStudioBindingEditorUtility.DrawManifestLink(manifest);
            var actions = manifest?.actions?.Where(value => !string.IsNullOrWhiteSpace(value)).ToArray() ?? Array.Empty<string>();
            var objects = manifest?.objects?.Where(value => !string.IsNullOrWhiteSpace(value.id)).Select(value => value.id).ToArray() ?? Array.Empty<string>();
            var action = serializedObject.FindProperty("action");
            BimStudioBindingEditorUtility.DrawChoice(action, "平台动作", actions, "请先在集成清单中声明平台动作，再在这里选择。");
            BimStudioBindingEditorUtility.DrawChoice(serializedObject.FindProperty("objectId"), "业务对象", objects, "未声明业务对象；留空时接收全局动作。", true);
            EditorGUILayout.PropertyField(serializedObject.FindProperty("onTriggered"), new GUIContent("收到动作时"));
            if (string.IsNullOrWhiteSpace(action.stringValue))
                EditorGUILayout.HelpBox("构建 WebGL 前请选择集成清单中的平台动作。", MessageType.Error);
            serializedObject.ApplyModifiedProperties();
        }
    }
}
